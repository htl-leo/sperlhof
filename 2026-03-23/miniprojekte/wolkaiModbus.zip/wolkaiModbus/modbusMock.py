from pymodbus.server import StartTcpServer
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusServerContext, ModbusDeviceContext

import threading
import time
import math
import random
from datetime import datetime

def set_16(slave, addr, val):
    slave.setValues(3, addr, [val & 0xFFFF])

def set_32(slave, addr, val):
    if val < 0:
        val = (1 << 32) + val
    hi = (val >> 16) & 0xFFFF
    lo = val & 0xFFFF
    slave.setValues(3, addr, [hi, lo])

def build_context():
    store = ModbusDeviceContext(
        hr=ModbusSequentialDataBlock(0, [0]*40000)
    )
    return ModbusServerContext(devices=store, single=True)

class HAInverterSim:
    def __init__(self, ctx):
        self.ctx = ctx[0]
        self.soc = 55.0
        self.capacity_wh = 10000

        self.total_energy = 5000000  # Wh
        self.daily_energy = 0

    def pv_curve(self):
        now = datetime.now()
        hour = now.hour + now.minute/60

        if hour < 6 or hour > 18:
            return 0

        x = (hour - 6) / 12 * math.pi
        return int(math.sin(x) * 10000)

    def house_load(self):
        base = random.randint(300, 700)

        if random.random() < 0.15:
            base += random.randint(1000, 2500)

        return base

    def step(self):
        pv = self.pv_curve()
        load = self.house_load()

        battery = 0

        if pv > load:
            battery = min(pv - load, 3000)
        else:
            battery = -min(load - pv, 3000)

        # SOC Update
        self.soc += battery / self.capacity_wh * 100 / 3600 * 2
        self.soc = max(5, min(100, self.soc))

        grid = pv + battery - load

        # Energie berechnen
        self.total_energy += max(pv, 0) / 3600 * 2
        self.daily_energy += max(pv, 0) / 3600 * 2

        # Reset Tageswert um Mitternacht
        if datetime.now().hour == 0:
            self.daily_energy = 0

        # -------------------
        # Register schreiben
        # -------------------

        # Spannung
        set_16(self.ctx, 30001, 2300)
        set_16(self.ctx, 30002, 2300)
        set_16(self.ctx, 30003, 2300)

        # Frequenz
        set_16(self.ctx, 30004, 5000)

        # Leistungen
        set_32(self.ctx, 30020, pv)        # PV Power
        set_32(self.ctx, 30010, pv + battery)
        set_32(self.ctx, 30060, grid)      # Grid

        # Batterie
        set_16(self.ctx, 30030, int(self.soc))
        set_32(self.ctx, 30031, int(battery))

        # Energie
        set_32(self.ctx, 30040, int(self.daily_energy))
        set_32(self.ctx, 30050, int(self.total_energy))

    def run(self):
        while True:
            self.step()
            time.sleep(2)

if __name__ == "__main__":
    context = build_context()
    sim = HAInverterSim(context)

    threading.Thread(target=sim.run, daemon=True).start()

    print("🏠 HA Modbus Mock läuft auf Port 5020")
    StartTcpServer(context, address=("0.0.0.0", 5020))